const monthNames = ["January", "February", "March", "April", "May", "June","July", "August", "September", "October", "November", "December"];
const currentMonth = monthNames[new Date().getMonth()];
document.getElementById("monthTitle").textContent = currentMonth;


const slides = document.querySelectorAll(".slide") ;
let currentSlide = 0 ;
function showSlide(index) {
    slides.forEach((slide,i)=>{
        slide.classList.toggle("active",i===index);
    });
}
function nextSlide(){
    currentSlide = (currentSlide+1)% slides.length;
    showSlide(currentSlide);
}
setInterval(nextSlide,3000);
showSlide(currentSlide);



let data = {} ;

const onSubscribe = () => {
    const name = document.querySelector("#name .in").value;
    const email = document.querySelector("#email .in").value;
    data[name] = email ;
    let jsonData = JSON.stringify(data) ;

};


alert(Object.keys(data).length);
    





